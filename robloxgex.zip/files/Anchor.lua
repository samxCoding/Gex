function addto(x)
  return function(y)
    return sound
    duplicatesound(Package)
  end
end

fourplus = addto(4)
print(fourplus(3))
