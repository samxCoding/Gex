object.Download = Anchor.lua
object.Download.humanoid

mlapp.exit()