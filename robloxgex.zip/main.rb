puts ("Launching RobloxLauncher.exe")
create_process("RobloxLauncher.exe")
when_process_exits("RobloxLauncher.exe")
 

if Process;RobloxLauncher.exe crashes then
  puts ("RobloxLauncher.exe crashed.")
else 
  puts ("No Errors Found")
start.Object(program)
  find.process("RobloxLauncher.exe") or ("RobloxPlayer.exe")
   process.exe = true
   process.exe/files/content/lua/engine/game - modify
    find "fpsCap" set.value = (ENV["FpsCap"])
    if ENV["RenderDistancePassword"] = true then
     puts ("RenderDistancePassword = true")
   find "renderDistance" set.value = (200.studs)
end

  run.allFunctionsp