local source = "https://roblox.com/experiences/loadid/"

git_source(:github) {|repo_name| "https://github.com/#{repo_name}" }
ENV["Github_Repo"]
# luaPart "rails"

Language = Lua.install


local function(ModuleCreate)
  create.serverScriptservice

  
  *ServerScriptService Code
      claim(Source)
    end
end